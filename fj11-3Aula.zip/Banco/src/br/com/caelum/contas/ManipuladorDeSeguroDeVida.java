package br.com.caelum.contas;

public class ManipuladorDeSeguroDeVida {



}
