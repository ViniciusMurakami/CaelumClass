package br.com.caelum.contas;
import br.com.caelum.javafx.api.util.Evento;
import br.com.caelum.contas.modelo.SeguroDeVida;


public class ManipuladorDeSeguroDeVida {
	private SeguroDeVida seguroDeVida;
	
	public void criaSeguros(Evento evento){
		this.seguroDeVida = new SeguroDeVida();
		this.seguroDeVida.setNumeroApolice(evento.getInt("numeroApolice"));
		this.seguroDeVida.setTitular(evento.getString("titular"));
		this.seguroDeVida.setValor(evento.getDouble("valor"));
	}


}
