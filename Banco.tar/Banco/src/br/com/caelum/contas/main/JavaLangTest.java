package br.com.caelum.contas.main;

import java.lang.reflect.*;
import java.util.Scanner;

public class JavaLangTest {
	// Method which validates the name of method
	public static boolean validaMetodo(String metodo) throws NoSuchMethodException {
		if (metodo.equals(Throwable.class.getDeclaredMethods())) {
			return true;
		} else if (metodo.equals(System.class.getDeclaredMethods())) {
			return true;
		}
		throw new NoSuchMethodException("Nao existe o metodo: " + metodo + "\n Voce quis dizer toString");
	}

	// Method which validates the name of Class
	public static boolean validaClasse(String classe) {
		try {
			for (Package p : Package.getPackages()) {
				System.out.println(p);
				Object instance = Class.forName(p + "." + classe).newInstance();
				return true;
			}
		} catch (Exception e) {
		}
		
		return false;
	}

	public static void main(String[] args) {
		/*
		 * String x = "System"; System.out.println(Object.class.forName));
		 */
		// Verificando a classe no input
		Scanner scan = new Scanner(System.in);
		System.out.println("Digite o nome da classe");
		String whichClass = scan.nextLine();
		scan.close();
			if (validaClasse(whichClass)) {
				System.out.println("TEM!");
			} else {
				System.out.println("Não tem!");

			}
		
	}

}
