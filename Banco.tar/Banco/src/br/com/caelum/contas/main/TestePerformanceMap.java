package br.com.caelum.contas.main;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class TestePerformanceMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Iniciando Map Teste de Performance...");
		Map<Integer, Integer> teste = new HashMap<Integer, Integer>();
		long inicio = System.currentTimeMillis();
		
		int total = 10000000;
		/*
		 * Iniciando Map Teste de Performance...
		 *	Tempo gasto insercao : 11788
		 *	Tempo gasto busca : 13160
		 */
		
		for(int i = 0; i < total; i++){
			teste.put(i, i);
		}
		long fim_insere = System.currentTimeMillis();
		long tempo_insere = fim_insere - inicio;
		System.out.println("Tempo gasto insercao : " + tempo_insere);
		
		for(int i = 0; i < total; i++){
			teste.get(i);
		}
		
		long fim_busca = System.currentTimeMillis();
		long tempo_busca = fim_busca - inicio;
		System.out.println("Tempo gasto busca : " + tempo_busca);

	}

}
