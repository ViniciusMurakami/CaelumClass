package br.com.caelum.contas.main;

import br.com.caelum.javafx.api.main.OlaMundo;
import br.com.caelum.javafx.api.main.TelaDeContas;

public class TestaJar {

	public static void main(String[] args) {
	//OlaMundo.main(args);
		/* Trace desta classe
		Runtime runtime = Runtime.getRuntime();
		runtime.traceMethodCalls(true);
		runtime.traceInstructions(true);
		System.out.println("Maximo de Memoria: " + runtime.maxMemory()+
							"\n" + "Trace da Classe: " + runtime.getClass());
		*/
	TelaDeContas.main(args);
	}
	
	

}
