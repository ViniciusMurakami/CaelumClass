package br.com.caelum.contas.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import br.com.caelum.contas.modelo.Conta;
import br.com.caelum.contas.modelo.ContaCorrente;

public class TestaLista {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		List<Conta> lista = new ArrayList<>();
		for(int i=0; i <= 10;i++){
			Random r = new Random();
			Conta c = new ContaCorrente(ThreadLocalRandom.current().nextInt(1, 999), r.nextInt(9999) + "", "Vini" + r.hashCode(),
					r.nextInt(1000) + " - " + r.nextInt(9));
			c.setDataDeAbertura(ThreadLocalRandom.current().nextInt(1990, 2017), ThreadLocalRandom.current().nextInt(1, 12), ThreadLocalRandom.current().nextInt(1, 28));
//			System.out.println(ThreadLocalRandom.current().nextInt(1990, 2017) + "/" + ThreadLocalRandom.current().nextInt(1, 12) + "/" + ThreadLocalRandom.current().nextInt(1, 28));
			lista.add(c);
			
		}
		System.out.println(lista.get(9).recuperarDadosParaImpressao());
//		System.out.println(lista.toString());
	}

}
