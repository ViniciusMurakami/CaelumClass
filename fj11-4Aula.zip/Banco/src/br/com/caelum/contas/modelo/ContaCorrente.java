package br.com.caelum.contas.modelo;

public class ContaCorrente extends Conta implements Tributavel {
	public ContaCorrente(double saldo, String numero, String titular, String agencia) {
		super(saldo, numero, titular, agencia);
	}

	public ContaCorrente(String titular) {
		super(titular);
	}

	public ContaCorrente() {
		super();
	}

	// Methods
	@Override
	public void saca(double valorDigitado) {
		if(valorDigitado < 0){
			throw new IllegalArgumentException("Voce tentou sacar" + " um valor negativo");
		}
		this.saldo -= (valorDigitado + .1);
	}

	
	// Getters & Setters
	@Override
	public double getValorImposto() {
		return this.saldo * 0.01;
	}
	
	@Override
	public String getTitular() {
		return this.titular;
	}
	
	@Override
	public String getTipo() {
		return "Conta Corrente";
	}

}
