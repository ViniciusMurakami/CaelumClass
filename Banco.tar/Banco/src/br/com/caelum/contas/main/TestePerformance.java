package br.com.caelum.contas.main;

import java.util.*;

public class TestePerformance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Iniciando o teste de HashSet / ArrayList...");
		Collection<Integer> teste = new HashSet<>();
		long inicio = System.currentTimeMillis();
		
		int total = 10000000;
		/*
		 * Iniciando o teste de HashSet / ArrayList...
		 *	Tempo gasto insercao : 12575
		 *	Tempo gasto busca : 13160
		 */
		
		for(int i = 0; i < total; i++){
			teste.add(i);
		}
		long fim_insere = System.currentTimeMillis();
		long tempo_insere = fim_insere - inicio;
		System.out.println("Tempo gasto insercao : " + tempo_insere);
		
		for(int i = 0; i < total; i++){
			teste.contains(i);
		}
		
		long fim_busca = System.currentTimeMillis();
		long tempo_busca = fim_busca - inicio;
		System.out.println("Tempo gasto busca : " + tempo_busca);
	}

}
