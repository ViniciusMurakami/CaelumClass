package br.com.caelum.contas.main;
import br.com.caelum.contas.modelo.Conta;
import br.com.caelum.contas.modelo.ContaCorrente;
import br.com.caelum.javafx.api.main.SistemaBancario;
 

public class TestaConta {
	public static void main(String[] args) throws Exception {
		
		//SistemaBancario.mostraTela(false);
		
		ContaCorrente c1 = new ContaCorrente("Vinicius");
		ContaCorrente c2 = new ContaCorrente("Vinicius");

		c1.deposito(20.0);
		c1.setNumero("12345");
		// c1.setTitular("Vinicius");
		c1.setDataDeAbertura(2004, 2, 25);
		c1.setAgencia("0451-8");
		c1.deposito(100.0);

		// System.out.println("Saldo atual: " + c1.saldo);
		// System.out.println("Rendimento Mensal: " + c1.calculaRendimento());
		c2.deposito(50.0);
		c2.setNumero("12345");
		// c2.setTitular("Vinicius");
		c2.setDataDeAbertura(2017, 8, 23);
		c2.setAgencia("0451-8");

		System.out.println(c1.recuperarDadosParaImpressao() + "\n\n" + c2.recuperarDadosParaImpressao());

		if (c1.getTitular().equals(c2.getTitular())) {
			System.out.println("Donos das contas iguais");
		} else {
			System.out.println("Donos das contas diferentes");
		}

		
		
		// c1.saca(10.0);
		// System.out.println("Saldo: " + c1.saldo);

		// c2.saca(10.0);
		// System.out.println("Saldo: " + c2.saldo);

		// c1.transfere(10, c2);

	}
}
