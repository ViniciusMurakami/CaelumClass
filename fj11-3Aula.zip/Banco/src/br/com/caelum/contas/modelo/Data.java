package br.com.caelum.contas.modelo;
public class Data {
	int dia, mes, ano;

	String dataFormatada() throws Exception {
		if (validaData()) {
			String dtFormatada = this.dia + "/" + this.mes + "/" + this.ano;
			return dtFormatada;
		} else {
			throw new Exception("Data Invalida");
		}
	}

	boolean validaData() {
		if (this.dia <= 0 || this.dia > 31 || this.mes <= 0 || this.mes > 12 || this.ano <= 0) {
			return false;
		} else if (
		// Ano bissexto
		(this.ano % 4 != 0 && this.ano % 100 == 0) && this.mes == 2 && this.dia > 29) {
			return false;
		} else if ((this.dia == 31 && this.mes == 3 || this.mes == 4 || this.mes == 6 || this.mes == 9
				|| this.mes == 11) || (this.dia >= 29 && this.mes == 2)) {
			return false;
		} else {
			return true;
		}

	}
}
