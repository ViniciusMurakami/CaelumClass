package br.com.caelum.contas.main;

public class TestandoDivisao {

	public static void main(String[] args) {
		int i = 5571;
		i = i / 0;
		System.out.println("O resultado " + i);

	}

}
