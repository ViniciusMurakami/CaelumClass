package br.com.caelum.contas.modelo;

/**
 * 
 * @author Vinicius Representa uma conta bancária
 * 
 */

public abstract class Conta implements Comparable<Conta> {
	// Attributes of Conta
	// Tip: Attribute its always related to whats this class have
	protected double saldo;
	private String numero;
	protected String titular;
	private String agencia;
	private Data dataDeAbertura = new Data();
	private static int contador; // Contador
	private int identificador;

	// Constructor
	public Conta(String titular) {
		this();
		this.titular = titular;
	}
	
	public Conta(double saldo, String numero, String titular, String agencia) {
		super();
		this.saldo = saldo;
		this.numero = numero;
		this.titular = titular;
		this.agencia = agencia;
	}

	public Conta() {
		Conta.contador++;
		this.setIdentificador();
	}

	// Methods of Conta
	// Tip: Method represents whats this class can do
	/*
	 * public boolean saca(double saldo) { if (saldo <= this.saldo) { this.saldo
	 * = this.saldo - saldo; return true; } else { return false; } }
	 */
	@Override
	public int compareTo(Conta outraConta){
		return this.titular.compareTo(outraConta.titular);
	}

	public void saca(double saldo) {
		//if(saldo < 0){
		//	throw new IllegalArgumentException("Voce tentou sacar" + " um valor negativo");
		//} else {
		this.saldo = this.saldo - saldo;
		//}
	}

	public void deposito(double saldo) {
		if(saldo < 0){
			throw new IllegalArgumentException("Voce tentou depositar" + " um valor negativo");
		} else {
		this.saldo += saldo;
		}
		//return;
	}

	public void transfere(double valor, Conta destino) {
		this.saca(valor);
		destino.deposito(valor);
	}

	public double calculaRendimento() {
		this.saldo = this.saldo * 0.1;
		return this.saldo;
	}

	public String recuperarDadosParaImpressao() throws Exception {
		String dados = "Titular: " + this.titular;
		dados += "\nNumero: " + this.numero;
		dados += "\nAgenda: " + this.agencia;
		dados += "\nDt Abertura: " + this.dataDeAbertura.dataFormatada();
		dados += "\nSaldo: " + this.saldo;
		dados += "\nidentificador: " + this.getIdentificador();
		dados += "\nTipo Conta: " + this.getTipo();
		return dados;
	}

	// Getters and Setters

	public static int getContador() {
		return Conta.contador;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public Data getDataDeAbertura() {
		return dataDeAbertura;
	}

	public void setDataDeAbertura(int ano, int mes, int dia) {
		this.dataDeAbertura.ano = ano;
		this.dataDeAbertura.mes = mes;
		this.dataDeAbertura.dia = dia;
	}

	public double getSaldo() {
		return saldo;
	}

	public int getIdentificador() {
		return identificador;
	}

	public void setIdentificador() {
		this.identificador = Conta.getContador();
	}

	public abstract String getTipo();
	/*{
		return "Conta";
	}*/
}
